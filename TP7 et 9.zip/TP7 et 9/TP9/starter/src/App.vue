<template>
  <div class="app">
    <header class="topbar">
      <h1>Météo en direct</h1>
      <button class="unit-toggle" @click="basculerUnite" v-if="ville">
        Afficher en {{ unite === 'metric' ? '°F' : '°C' }}
      </button>
    </header>

    <div class="search">
      <input
        v-model="query"
        @input="onInputRecherche"
        type="text"
        placeholder="Rechercher une ville... (ex: Safi, Paris, Tokyo)"
      />
      <p class="hint" v-if="chargementSuggestions">Recherche...</p>
      <p class="msg-error" v-if="erreurSuggestions">{{ erreurSuggestions }}</p>

      <ul class="suggestions" v-if="suggestions.length">
        <li v-for="s in suggestions" :key="s.lat + '-' + s.lon" @click="choisirVille(s)">
          {{ s.name }}<span v-if="s.state">, {{ s.state }}</span> ({{ s.country }})
        </li>
      </ul>
    </div>

    <div class="historique" v-if="historique.length">
      <span>Récent :</span>
      <button v-for="h in historique" :key="h.lat + '-' + h.lon" @click="choisirVille(h)">
        {{ h.name }}
      </button>
    </div>

    <div class="meteo" v-if="ville">
      <p class="loading" v-if="chargementMeteo">Chargement de la météo...</p>
      <p class="msg-error" v-else-if="erreurMeteo">{{ erreurMeteo }}</p>

      <div v-else-if="meteoActuelle" class="courante">
        <h2>{{ ville.name }}, {{ ville.country }}</h2>
        <div class="temp-actuelle">
          <img :src="iconeUrl(meteoActuelle.weather[0].icon)" :alt="meteoActuelle.weather[0].description" />
          <span class="valeur">{{ Math.round(meteoActuelle.main.temp) }}°</span>
          <span class="description">{{ meteoActuelle.weather[0].description }}</span>
        </div>
        <p class="details">
          Ressenti {{ Math.round(meteoActuelle.main.feels_like) }}° · Humidité {{ meteoActuelle.main.humidity }}%
        </p>
      </div>

      <div class="previsions" v-if="previsionsParJour.length">
        <div class="jour" v-for="j in previsionsParJour" :key="j.date">
          <span class="date">{{ j.date }}</span>
          <img :src="iconeUrl(j.icone)" :alt="j.description" />
          <span class="temps">{{ Math.round(j.min) }}° / {{ Math.round(j.max) }}°</span>
        </div>
      </div>
    </div>

    <p class="empty" v-if="!ville">Cherchez une ville pour voir sa météo.</p>
  </div>
</template>

<script>
const API_KEY = import.meta.env.VITE_OWM_API_KEY
const GEO_URL = 'https://api.openweathermap.org/geo/1.0/direct'
const WEATHER_URL = 'https://api.openweathermap.org/data/2.5/weather'
const FORECAST_URL = 'https://api.openweathermap.org/data/2.5/forecast'

function lireHistorique() {
  try {
    const brut = localStorage.getItem('historique')
    const donnees = brut ? JSON.parse(brut) : []
    return Array.isArray(donnees) ? donnees : []
  } catch (e) {
    return []
  }
}

export default {
  name: 'App',
  data() {
    return {
      query: '',
      debounceTimer: null,
      suggestions: [],
      chargementSuggestions: false,
      erreurSuggestions: null,

      ville: null,
      historique: lireHistorique(),

      meteoActuelle: null,
      previsions: [],
      chargementMeteo: false,
      erreurMeteo: null,

      unite: 'metric'
    }
  },
  computed: {
    previsionsParJour() {
      const jours = {}
      for (const p of this.previsions) {
        const [date, heure] = p.dt_txt.split(' ')
        const ecartMidi = Math.abs(parseInt(heure.slice(0, 2), 10) - 12)
        const jour = jours[date]
        if (!jour) {
          jours[date] = {
            date,
            min: p.main.temp_min,
            max: p.main.temp_max,
            icone: p.weather[0].icon,
            description: p.weather[0].description,
            ecartMidi
          }
        } else {
          jour.min = Math.min(jour.min, p.main.temp_min)
          jour.max = Math.max(jour.max, p.main.temp_max)
          if (ecartMidi < jour.ecartMidi) {
            jour.icone = p.weather[0].icon
            jour.description = p.weather[0].description
            jour.ecartMidi = ecartMidi
          }
        }
      }
      return Object.values(jours)
        .sort((a, b) => a.date.localeCompare(b.date))
        .map(({ date, min, max, icone, description }) => ({ date, min, max, icone, description }))
    }
  },
  methods: {
    iconeUrl(code) {
      return `https://openweathermap.org/img/wn/${code}@2x.png`
    },

    onInputRecherche() {
      clearTimeout(this.debounceTimer)
      if (!this.query.trim()) {
        this.suggestions = []
        this.erreurSuggestions = null
        this.chargementSuggestions = false
        return
      }
      this.debounceTimer = setTimeout(() => {
        this.rechercherVilles()
      }, 400)
    },

    async rechercherVilles() {
      const requete = this.query.trim()
      if (!requete) return
      this.chargementSuggestions = true
      this.erreurSuggestions = null
      try {
        const reponse = await fetch(
          `${GEO_URL}?q=${encodeURIComponent(requete)}&limit=5&appid=${API_KEY}`
        )
        if (requete !== this.query.trim()) return
        if (reponse.status === 401) {
          this.suggestions = []
          this.erreurSuggestions = 'Cle API invalide ou absente.'
          return
        }
        if (reponse.status === 429) {
          this.suggestions = []
          this.erreurSuggestions = 'Quota depasse, reessayez plus tard.'
          return
        }
        if (!reponse.ok) throw new Error(`Erreur ${reponse.status}`)
        const villes = await reponse.json()
        if (requete !== this.query.trim()) return
        this.suggestions = villes
        if (villes.length === 0) {
          this.erreurSuggestions = 'Aucune ville trouvee pour cette recherche.'
        }
      } catch (e) {
        this.suggestions = []
        this.erreurSuggestions = 'Impossible de contacter le service de geocodage.'
      } finally {
        if (requete === this.query.trim()) this.chargementSuggestions = false
      }
    },

    choisirVille(ville) {
      clearTimeout(this.debounceTimer)
      this.suggestions = []
      this.erreurSuggestions = null
      this.chargementSuggestions = false
      this.query = ''
      this.ville = ville
      this.historique = [
        ville,
        ...this.historique.filter(h => !(h.lat === ville.lat && h.lon === ville.lon))
      ].slice(0, 5)
      try {
        localStorage.setItem('historique', JSON.stringify(this.historique))
      } catch (e) {
        return this.chargerMeteo()
      }
      return this.chargerMeteo()
    },

    async chargerMeteo() {
      if (!this.ville) return
      const { lat, lon } = this.ville
      const parametres = `lat=${lat}&lon=${lon}&appid=${API_KEY}&units=${this.unite}&lang=fr`
      this.chargementMeteo = true
      this.erreurMeteo = null
      try {
        const [repMeteo, repPrevisions] = await Promise.all([
          fetch(`${WEATHER_URL}?${parametres}`),
          fetch(`${FORECAST_URL}?${parametres}`)
        ])
        for (const r of [repMeteo, repPrevisions]) {
          if (r.status === 401) throw new Error('Cle API invalide ou absente.')
          if (r.status === 429) throw new Error('Quota depasse, reessayez plus tard.')
          if (!r.ok) throw new Error(`Erreur ${r.status}`)
        }
        const [meteo, previsions] = await Promise.all([repMeteo.json(), repPrevisions.json()])
        if (this.ville.lat !== lat || this.ville.lon !== lon) return
        this.meteoActuelle = meteo
        this.previsions = previsions.list
      } catch (e) {
        this.meteoActuelle = null
        this.previsions = []
        this.erreurMeteo = e.message.startsWith('Erreur') || e.message.includes('Cle') || e.message.includes('Quota')
          ? e.message
          : 'Impossible de charger la meteo.'
      } finally {
        this.chargementMeteo = false
      }
    },

    basculerUnite() {
      this.unite = this.unite === 'metric' ? 'imperial' : 'metric'
      return this.chargerMeteo()
    }
  }
}
</script>
